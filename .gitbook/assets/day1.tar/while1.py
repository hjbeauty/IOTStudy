count = 0

while count < 3:
    count = count + 1
    print("Number : %d" %count)
    
print("End of program...")
    