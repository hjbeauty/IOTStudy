tot = 0
num = 0

while True:
    num += 1
    tot += num
    
    if num == 10:
        break
    
print("sum : %d" %tot)