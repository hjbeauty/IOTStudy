name = ['kim', 'lee', 'park', 'jung', 'song']
str1 = 'seoul'
dic = {'age':23, 'name':'kim'}

for var in name:
    print("My name is %s." %var)
    
for var in str1:
    print(var)
    
for var in dic.keys():
    print("%s : %s" %(var, dic[var]))
