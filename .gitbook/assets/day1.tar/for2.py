tot = 0

for num in range(1, 11):
    tot += num
    
print("SUM(1 - 10) : %d" %tot)
