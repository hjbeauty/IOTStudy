from tkinter import *

root = Tk()

root.geometry('300x100')

label = Label(root, text = 'hello world')

label.pack()

root.mainloop()