from tkinter import *

root = Tk()

root.geometry('300x100+50+50')

def func():
    print('Pushed!!!')

button = Button(root, text='push!', command = func)

button.pack()

root.mainloop()