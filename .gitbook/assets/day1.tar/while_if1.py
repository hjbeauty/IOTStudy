ans = 'y'

while ans == 'y':
    num = int(input("Input number : "))

    if (num % 2) == 0:
        print("%d is even number" %num)
    else:
        print("%d is odd number" %num)
    
    ans = input("Continue(y/n) ? ")
    
print("Done...")
    