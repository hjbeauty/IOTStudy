num = int(input("Input number : "))

if (num % 2) == 0:
    print("%d is even number" %num)
else:
    print("%d is odd number" %num)
    
print("Done...")
    