import time

try:
    while True:
        print('Good Morning!!')
        print('Have a nice day!!')
        time.sleep(1)
        
except KeyboardInterrupt:
    pass

print("End of program...")