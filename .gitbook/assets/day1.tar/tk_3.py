from tkinter import *

root = Tk()

root.geometry('300x100+50+50')

def func():
    label.config(text = 'Pushed!!!')
    
label = Label(root, text = 'Push Button')

button = Button(root, text='push!', command = func)

label.pack()

button.pack()

root.mainloop()