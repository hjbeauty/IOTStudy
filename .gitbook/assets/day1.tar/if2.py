num = int(input("Input number : "))

if num > 0:
    print("plus")
elif num < 0:
    print("minus")
else:
    print("zero")
    
print("Done...")
    