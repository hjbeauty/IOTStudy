from tkinter import *

root = Tk()

c = Canvas(root, width = 500, height = 500)
c.pack()

c.create_rectangle(100,100,150,150, fill = 'red')
c.create_oval(100, 200, 150, 300, fill = 'blue')

root.mainloop()