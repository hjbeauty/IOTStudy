tot = 0
num = 0

while num < 100:
    num += 1
        
    if (num % 2) == 1:
        continue
    
    tot = tot + num
    
print("sum of even number : %d" %tot)