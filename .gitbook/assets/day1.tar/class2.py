class FourCal:
    def __init__(self, first, second):
        self.first = first
        self.second = second
        
    def add(self):
        self.result = self.first + self.second
        return self.result
    
    def mul(self):
        self.result = self.first * self.second
        return self.result
    
    def sub(self):
        self.result = self.first - self.second
        return self.result
    
    def div(self):
        self.result = self.first / self.second
        return self.result
    
a = FourCal(4,2)

print(a.add())
print(a.mul())
print(a.sub())
print(a.div())