tot = 0
num = 0

while num < 100:
   num += 1      #num = num + 1
   
   if (num % 2) == 1:
       tot += num    #tot = tot + num
    
print("sum of even number(1-100) : %d" %tot)
    