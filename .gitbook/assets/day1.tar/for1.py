for num in range(1, 11):
    print("number : %d" %num)
