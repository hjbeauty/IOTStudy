tot = 0
num = 0

while num < 100:
   num += 1      #num = num + 1
   tot += num    #tot = tot + num
    
print("Sum(1 - %d) : %d" %(num, tot))
    