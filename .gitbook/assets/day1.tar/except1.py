a = ['a', 'b', 'c']

number = int(input('Input number(0~2) : '))

try:
    b= a[number]
except IndexError:
    print('Index Error..')
    
else:
    print("a[%d] : %s" %(number, b))
    
finally:
    print("End of program...")