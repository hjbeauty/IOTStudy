import RPi.GPIO as GPIO
from time import sleep

buzzer = 22
do = 5
re = 6
mi = 13
fa = 19
sol = 26

freq = [262, 294, 330, 349, 392]
dic_pin = {5:0, 6:1, 13:2, 19:3, 26:4}

GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
GPIO.setup(buzzer, GPIO.OUT)
GPIO.setup(do, GPIO.IN, pull_up_down = GPIO.PUD_UP)
GPIO.setup(re, GPIO.IN, pull_up_down = GPIO.PUD_UP)
GPIO.setup(mi, GPIO.IN, pull_up_down = GPIO.PUD_UP)
GPIO.setup(fa, GPIO.IN, pull_up_down = GPIO.PUD_UP)
GPIO.setup(sol, GPIO.IN, pull_up_down = GPIO.PUD_UP)

p = GPIO.PWM(buzzer, 1)

p.start(0)

def sound_buz(pin):
    if GPIO.input(pin) == GPIO.LOW:
        p.ChangeDutyCycle(50)
        p.ChangeFrequency(freq[dic_pin[pin]])
        
    else:
        p.ChangeDutyCycle(0)
        

GPIO.add_event_detect(do, GPIO.BOTH, callback = sound_buz, bouncetime = 100)
GPIO.add_event_detect(re, GPIO.BOTH, callback = sound_buz, bouncetime = 100)
GPIO.add_event_detect(mi, GPIO.BOTH, callback = sound_buz, bouncetime = 100)
GPIO.add_event_detect(fa, GPIO.BOTH, callback = sound_buz, bouncetime = 100)
GPIO.add_event_detect(sol, GPIO.BOTH, callback = sound_buz, bouncetime = 100)


try:
    while True:
        pass
        
except KeyboardInterrupt:
    pass

p.stop()
GPIO.cleanup()