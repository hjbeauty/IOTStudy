import RPi.GPIO as GPIO
from time import sleep

switch = 20
GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
GPIO.setup(switch, GPIO.IN)

try:
    while True:
        switch_in = GPIO.input(switch)
        
        print(switch_in)
        sleep(0.5)
        
except KeyboardInterrupt:
    pass

GPIO.cleanup()
