import RPi.GPIO as GPIO
from time import sleep

led =12
switch = 20

GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
GPIO.setup(led, GPIO.OUT, initial = GPIO.LOW)
GPIO.setup(switch, GPIO.IN)

try:
    while True:
        switch_in = GPIO.input(switch)
        
        if switch_in == 0:
            GPIO.output(led, GPIO.HIGH)
        else:
            GPIO.output(led, GPIO.LOW)
            
except KeyboardInterrupt:
    pass
        
GPIO.cleanup()