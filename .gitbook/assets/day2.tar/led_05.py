import RPi.GPIO as GPIO
from time import sleep

led = 12
GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
GPIO.setup(led, GPIO.OUT, initial = GPIO.LOW)

led_bt = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 13, 16, 20, 30, 50, 70, 100]

p = GPIO.PWM(led, 100)

GPIO.cleanup()

p.start(0)

try:
    while True:
        for var in led_bt:
            p.ChangeDutyCycle(var)
            sleep(1)
            
       # led_bt.reverse()
       # sleep(2)
       
except KeyboardInterrupt:
    pass

p.stop()

GPIO.cleanup()