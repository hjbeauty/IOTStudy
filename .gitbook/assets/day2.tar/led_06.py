import RPi.GPIO as GPIO
from tkinter import *

led = 12
GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
GPIO.setup(led, GPIO.OUT, initial = GPIO.LOW)

p = GPIO.PWM(led, 100)

root = Tk()
root.geometry('300x300+50+50')

led_bt = DoubleVar()
led_bt.set(0)

p.start(0)

def change_duty(dc):
    p.ChangeDutyCycle(led_bt.get())
    
s = Scale(root, label = 'LED', orient = 'h', from_ = 0, to = 100, \
          variable = led_bt, command = change_duty)

s.pack()

root.mainloop()

p.stop()

GPIO.cleanup()
