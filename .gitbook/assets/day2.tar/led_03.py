import RPi.GPIO as GPIO
from time import sleep

led = 12
GPIO.setmode(GPIO.BCM)
GPIO.setup(led, GPIO.OUT, initial = GPIO.LOW)

try:
    while True:
        GPIO.output(led, GPIO.HIGH)
        sleep(0.5)

        GPIO.output(led, GPIO.LOW)
        sleep(0.5)

except KeyboardInterrupt:
    pass

GPIO.cleanup()