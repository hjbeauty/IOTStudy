import RPi.GPIO as GPIO
import tkinter

led = 12
switch = 20

GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
GPIO.setup(switch, GPIO.IN, pull_up_down = GPIO.PUD_UP)
GPIO.setup(led, GPIO.OUT, initial = GPIO.LOW)

root = tkinter.Tk()

c = tkinter.Canvas(root, width = 200, height = 200)
c.pack()

cc = c.create_oval(50, 50, 150, 150, fill = '')

def check_switch(channel):
    switch_in = GPIO.input(channel)
    
    if switch_in == 0:
        GPIO.output(led, GPIO.HIGH)
        c.itemconfig(cc, fill = 'red')
    else:
        GPIO.output(led, GPIO.LOW)
        c.itemconfig(cc, fill = '')
        

GPIO.add_event_detect(switch, GPIO.BOTH, callback = check_switch, \
                      bouncetime = 100)

root.mainloop()

GPIO.cleanup()