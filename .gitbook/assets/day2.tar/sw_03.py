import RPi.GPIO as GPIO
from time import sleep

led =12
switch = 20
state = 0

GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
GPIO.setup(led, GPIO.OUT, initial = GPIO.LOW)
GPIO.setup(switch, GPIO.IN)

try:
    while True:
        if GPIO.input(switch) == 0:
            
            while True:
                if GPIO.input(switch) == 0:
                    state = not state
                    GPIO.output(led, state)
                    sleep(0.2)
                    break
            
except KeyboardInterrupt:
    pass
        
GPIO.cleanup()