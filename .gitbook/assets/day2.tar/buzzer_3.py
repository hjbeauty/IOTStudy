import RPi.GPIO as GPIO
from time import sleep

buzzer = 22
switch = 20

GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
GPIO.setup(buzzer, GPIO.OUT)
GPIO.setup(switch, GPIO.IN, pull_up_down = GPIO.PUD_UP)

p = GPIO.PWM(buzzer, 1)

p.start(50)

try:
    while True:
        if GPIO.input(switch) == GPIO.LOW:
            p.ChangeDutyCycle(50)
            p.ChangeFrequency(262)
        else:
            p.ChangeDutyCycle(0)
            
except KeyboardInterrupt:
    pass
           
p.stop()

GPIO.cleanup()