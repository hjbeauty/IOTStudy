import RPi.GPIO as GPIO
from time import sleep

buzzer = 22

GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
GPIO.setup(buzzer, GPIO.OUT)

p = GPIO.PWM(buzzer, 1)

p.start(50)

p.ChangeFrequency(262)
sleep(3)

p.stop()

GPIO.cleanup()