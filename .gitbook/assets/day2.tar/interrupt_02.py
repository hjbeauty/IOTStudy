import RPi.GPIO as GPIO
from time import sleep

led = 12
switch = 20
led_on = 0

GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
GPIO.setup(switch, GPIO.IN, pull_up_down = GPIO.PUD_UP)
GPIO.setup(led, GPIO.OUT, initial = GPIO.LOW)

def keyHandler(n):
    global led_on
    led_on = led_on ^ 1
    
GPIO.add_event_detect(switch, GPIO.FALLING, callback = keyHandler, bouncetime = 100)

try:
    while True:
        GPIO.output(led, led_on)
        
except KeyboardInterrupt:
    pass
        
GPIO.cleanup()