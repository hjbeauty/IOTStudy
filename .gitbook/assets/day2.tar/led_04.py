import RPi.GPIO as GPIO
import tkinter

led = 12
GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
GPIO.setup(led, GPIO.OUT, initial = GPIO.LOW)

def func_led():
    GPIO.output(led, not GPIO.input(led))

root = tkinter.Tk()
root.geometry('300x300+50+50')

label = tkinter.Label(root, text = 'press button')
label.pack()

button = tkinter.Button(root, text = 'LED', command = func_led)
button.pack()

root.mainloop()

GPIO.cleanup()