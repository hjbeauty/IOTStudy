import RPi.GPIO as GPIO
from time import sleep

buzzer = 22
do = 5
re = 6
mi = 13
fa = 19
sol = 26
freq = [262, 294, 330, 349, 392]

GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
GPIO.setup(buzzer, GPIO.OUT)
GPIO.setup(do, GPIO.IN, pull_up_down = GPIO.PUD_UP)
GPIO.setup(re, GPIO.IN, pull_up_down = GPIO.PUD_UP)
GPIO.setup(mi, GPIO.IN, pull_up_down = GPIO.PUD_UP)
GPIO.setup(fa, GPIO.IN, pull_up_down = GPIO.PUD_UP)
GPIO.setup(sol, GPIO.IN, pull_up_down = GPIO.PUD_UP)

p = GPIO.PWM(buzzer, 1)

p.start(0)

try:
    while True:
        if GPIO.input(do) == GPIO.LOW:
            p.ChangeDutyCycle(50)
            p.ChangeFrequency(freq[0])
            
        elif GPIO.input(re) == GPIO.LOW:
            p.ChangeDutyCycle(50)
            p.ChangeFrequency(freq[1])
        
        elif GPIO.input(mi) == GPIO.LOW:
            p.ChangeDutyCycle(50)
            p.ChangeFrequency(freq[2])
            
        elif GPIO.input(fa) == GPIO.LOW:
            p.ChangeDutyCycle(50)
            p.ChangeFrequency(freq[3])
            
        elif GPIO.input(sol) == GPIO.LOW:
            p.ChangeDutyCycle(50)
            p.ChangeFrequency(freq[4])
            
        else:
            p.ChangeDutyCycle(0)       
    
except KeyboardInterrupt:
    pass

finally:
    p.stop()
    
GPIO.cleanup()