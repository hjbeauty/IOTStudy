import RPi.GPIO as GPIO
from time import sleep

switch = 20

GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
GPIO.setup(switch, GPIO.IN, pull_up_down = GPIO.PUD_UP)

def KeyHandler(pin):
    print("Key is pressed [%d]" %pin)
    
GPIO.add_event_detect(switch, GPIO.FALLING, callback = KeyHandler)

num = 0

try:
    while True:
        print("sec : %d" %num)
        num = num + 1
        sleep(1)
            
except KeyboardInterrupt:
    pass
        
GPIO.cleanup()